# blazor-webassembly-basic-authentication-example

ASP.NET Core Blazor WebAssembly - Basic HTTP Authentication Example

For documentation and demo see https://jasonwatmore.com/post/2020/09/10/blazor-webassembly-basic-http-authentication-tutorial-example