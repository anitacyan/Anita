﻿
using System;
using System.Collections.Generic;


namespace AnitaGupta
{
    public class Order
    {
        public long OrderId { get; set; }
        public long SecurityId { get; set; }
        public double Quantity { get; set; }
        public double Price { get; set; }

        public virtual Security Security { get; set; }
    }

    public class Security
    {
        public Security()
        {
            Order = new List<Order>();
        }

        public long SecurityId { get; set; }
        public string Ticker { get; set; }
        public byte[] CompanyLogo { get; set; }

        public string CompanyName { get; set; }
        public List<Order> Order { get; set; }
    }

    public class Security64
    {
        public Security64()
        {
            Order = new List<Order>();
        }

        public long SecurityId { get; set; }
        public string Ticker { get; set; }

        public string CompanyLogo { get; set; }

        public string CompanyName { get; set; }
        public List<Order> Order { get; set; }
    }

    
}
