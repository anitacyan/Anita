﻿using Microsoft.EntityFrameworkCore;


namespace AnitaGupta
{
    public partial class TradeDBContext : DbContext
    {
        public TradeDBContext()
        {
        }

        public TradeDBContext(DbContextOptions<TradeDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Order> Order { get; set; }
        public virtual DbSet<Security> Security { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=DESKTOP-GUFIHQA;Database=AnitaDB;Trusted_Connection=True;MultipleActiveResultSets=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Order>(entity =>
            {
                entity.HasOne(d => d.Security)
                    .WithMany(p => p.Order)
                    .HasForeignKey(d => d.SecurityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Order_Security");

            });

            modelBuilder.Entity<Security>(entity =>
            {
                entity.Property(e => e.SecurityId).HasColumnName("SecurityID");
                entity.Property(e => e.Ticker).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

