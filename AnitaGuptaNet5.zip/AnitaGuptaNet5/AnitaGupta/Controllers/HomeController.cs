﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AnitaGupta
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private TradeDBContext _context = new TradeDBContext();
        private static bool isAuthenticated = false;

        IConfiguration configuration;
        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            configuration = config;
        }

        public IActionResult Index()
        {
            if (configuration.GetSection("Authenticate").Value == "true")
            {
                if (!isAuthenticated)
                {
                    string url = "https://localhost:44330/login?returnUrl=" + HttpContext.Request.GetEncodedUrl() + "Home/AfterAuthenticate";
                    return Redirect(url);
                }
                else return View();
            }

            else return View();
        }

        [HttpGet]
        public IActionResult AfterAuthenticate(string s)
        {
            isAuthenticated = true;
            return View("index");
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return Content("Error");
        }



        private static string ImageByteToBase64ImageTag(byte[] array)
        {
            string s = "";
            if (array != null)
            {
                string base64 = Convert.ToBase64String(array);
                s = "<img  src=\"data:image/png;base64," + base64 + " \"  />";
            }
            return s;
        }

        [HttpGet]
        public ActionResult GetSecurity()
        {

            var security = _context.Security.ToList();
            List<Security64> s64 = new List<Security64>();


            foreach (var s in security)
            {
                Security64 s6 = new Security64() { SecurityId = s.SecurityId, CompanyName = s.CompanyName, Ticker = s.Ticker,CompanyLogo= ImageByteToBase64ImageTag(s.CompanyLogo) };
                s64.Add(s6);
            }

            return Json(new { data = s64 },new JsonSerializerOptions());

        }



        [HttpGet]
        public ActionResult Save(int id)
        {
            var v = _context.Security.Where(a => a.SecurityId == id).FirstOrDefault();
            return View(v);
        }

        [HttpPost]
        public ActionResult Save(Security emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.SecurityId > 0)
                {
                    var v = _context.Security.Where(a => a.SecurityId == emp.SecurityId).FirstOrDefault();
                    if (v != null)
                    {
                        v.Ticker = emp.Ticker;
                        v.CompanyName = emp.CompanyName;

                    }
                }
                else
                {
                    _context.Security.Add(emp);
                }

                _context.SaveChanges();
                status = true;
            }

            if (status) return new JsonResult("Security is saved. Please close Browser and refresh. Will build automatic refresh in Version 2.");
            else return new JsonResult("Error saving Security.");
        }

      




        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = _context.Security.Where(a => a.SecurityId == id).FirstOrDefault();
            if (v != null)
            {
                return View("Delete",v);
            }
            else
            {
                return new JsonResult("No security found to delete");
            }

        }

        private ActionResult HttpNotFound()
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteSecurity(int id)
        {
            bool status = false;

            var v = _context.Security.Where(a => a.SecurityId == id).FirstOrDefault();
            if (v != null)
            {
                var o = _context.Order.Where(a => a.SecurityId == id).AsEnumerable();
                foreach (var o2 in o)
                    _context.Order.Remove(o2);

                _context.Security.Remove(v);
                _context.SaveChanges();
                status = true;
            }

            if (status) return new JsonResult("Security is deleted. Please close Browser and refresh. Will build automatic refresh in Version 2.");
            else return new JsonResult("An error occurred deleting Security.");

        }

        [HttpGet]
        public ActionResult orders(int id)
        {
            return View("Order", id);
        }
        [HttpGet]
        public ActionResult GetOrders(int id)
        {

            var v = _context.Order.Where(a => a.SecurityId == id).ToList();

            return Json(new { data = v }, new JsonSerializerOptions());

        }

        [HttpGet]
        public ActionResult saveorder(int id)
        {
            var v = _context.Order.Where(a => a.OrderId == id).FirstOrDefault();
            return View("SaveOrder", v);
        }

        [HttpGet]
        public ActionResult addorder(int id)
        {
            Order o = new Order();o.SecurityId = id;return View("saveorder", o);

        }

        [HttpPost]
        public ActionResult saveorder(Order o)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (o.OrderId > 0)
                {
                    var v = _context.Order.Where(a => a.OrderId == o.OrderId).FirstOrDefault();
                    if (v != null)
                    {
                        v.Price = o.Price;
                        v.Quantity = o.Quantity;

                    }
                }
                else
                {


                    _context.Order.Add(o);
                }

                _context.SaveChanges();
                status = true;
            }

            if (status) return new JsonResult("Order is saved. Please close Browser and refresh. Will build automatic refresh in Version 2.");
            else return new JsonResult("Error saving Order.");
        }

    }
}
